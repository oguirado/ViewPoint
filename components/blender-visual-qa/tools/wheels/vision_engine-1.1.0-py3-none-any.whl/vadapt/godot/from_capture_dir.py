# @module {"id":"va.godot","layer":4,"stage":"ADAPT","owner":"ARCH","deps":["vc.canon","vc.decode","vc.errors"],"book":"HB-VC-a0-arch"}
"""@module va.godot - godot-visual-qa capture dir (vqa.capture/v1 manifest + PNG frames + telemetry.jsonl) ->
vqa.frame/v1 manifest + vqa.region-hint/v1 rows (SPEC_ARCH §4-§5). Reads only what v1.0 wrote; no Godot import.

Layout read (run root R, or R/capture itself): manifest.json | capture/manifest.json (frames[].file.path relative to R,
frames[].decoded_rgb_sha256 optional), telemetry (manifest telemetry.path, default telemetry.jsonl) with `ui` and
`actors` rects in px_q16 [x,y,w,h]; optional still probe: R/still_probe/*.png (or probe/)."""
import argparse
import hashlib
import json
import os
import re
import sys
from pathlib import Path

import numpy as np

from visioncore import canon, frame as vframe

from visioncore.decode import png as read_png
from visioncore.errors import VqaError, result_line, result_obj

ADAPTER_ID = "godot"
ADAPTER_VERSION = "1"
_NAME_BAD = re.compile(r"[^a-z0-9_]+")


def _load_json(path):
    try:
        with open(path, encoding="utf-8") as fh:
            return json.load(fh)
    except OSError as e:
        raise VqaError("E_IO", {"path": str(path), "reason": str(e)[:80]})
    except ValueError as e:
        raise VqaError("E_VC_FRAME_SCHEMA", {"path": str(path), "reason": str(e)[:80]})


def _slug(s, n):
    s = _NAME_BAD.sub("_", str(s).lower()).strip("_")[:n]
    return s or "unknown"


def _roots(run_dir):
    """-> (manifest_path, root) where root resolves the relative `capture/frames/...` paths."""
    d = Path(run_dir)
    for cand, root in ((d / "capture" / "manifest.json", d), (d / "manifest.json", d.parent if d.name == "capture" else d)):
        if cand.is_file():
            return cand, root
    raise VqaError("E_IO", {"path": str(d), "reason": "no capture/manifest.json or manifest.json"})


def _resolve(root, manifest_path, rel):
    for base in (root, manifest_path.parent):
        p = base / rel
        if p.is_file():
            return p
    raise VqaError("E_IO", {"path": str(root / rel), "reason": "frame file missing"})


def _sha_file(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def _rect_px(r, W, H):
    """px_q16 [x,y,w,h] -> clipped integer [x,y,w,h] covering the rect (floor origin, ceil far edge) or None."""
    if not isinstance(r, (list, tuple)) or len(r) != 4 or not all(isinstance(v, int) and not isinstance(v, bool) for v in r):
        return None
    x0, y0 = r[0] >> 16, r[1] >> 16
    x1, y1 = -((-(r[0] + r[2])) >> 16), -((-(r[1] + r[3])) >> 16)
    x0, y0, x1, y1 = max(0, x0), max(0, y0), min(W, x1), min(H, y1)
    if x1 <= x0 or y1 <= y0:
        return None
    return [x0, y0, x1 - x0, y1 - y0]


def _rows_for(tel, i, W, H):
    out, seen = [], set()
    for kind, key, bkey, role in (("ui", "ui", "rect_px_q16", "ui"), ("actors", "actors", "screen_bounds_px_q16", "actor")):
        items = tel.get(key)
        if not isinstance(items, list):
            continue
        for it in items:
            if not isinstance(it, dict) or it.get("visible") is not True:
                continue
            if kind == "actors" and (it.get("alive") is False or it.get("frustum_inside") is False or it.get("in_front") is False):
                continue
            bb = _rect_px(it.get(bkey), W, H)
            if bb is None:
                continue
            rid = "h:%s:%s" % (role, _slug(it.get("id", ""), 40))
            if rid in seen:
                continue
            seen.add(rid)
            out.append({"i": i, "rid": rid, "role": role, "bbox_px": bb, "z": None})
    return sorted(out, key=lambda r: r["rid"])


class GodotAdapter:
    id = ADAPTER_ID
    version = ADAPTER_VERSION

    def _read(self, run_dir):
        mp, root = _roots(run_dir)
        cap = _load_json(mp)
        if not isinstance(cap, dict) or not isinstance(cap.get("frames"), list) or not cap["frames"]:
            raise VqaError("E_VC_FRAME_SCHEMA", {"path": str(mp), "reason": "no frames"})
        recs = sorted(cap["frames"], key=lambda r: r.get("render_index", -1))
        return mp, root, cap, recs

    def frames(self, run_dir):
        mp, root, cap, recs = self._read(run_dir)
        fps = cap.get("fps") if isinstance(cap.get("fps"), int) and cap["fps"] > 0 else 30
        frames, entries, W = [], [], None
        for k, r in enumerate(recs):
            ri = r.get("render_index")
            f = r.get("file") or {}
            if not isinstance(ri, int) or isinstance(ri, bool) or ri < 0 or not isinstance(f.get("path"), str):
                raise VqaError("E_VC_FRAME_SCHEMA", {"field": "frames[%d]" % k})
            p = _resolve(root, mp, f["path"])
            fsha = _sha_file(p)
            if f.get("sha256") not in (None, fsha):
                raise VqaError("E_VC_FRAME_SHA", {"i": k, "reason": "file sha256"})
            rgb = read_png(p)
            fr = vframe.Frame(k, ri * 1000000 // fps, ri, rgb, r.get("decoded_rgb_sha256"))
            if W is None:
                W = rgb.shape[1], rgb.shape[0]
            elif (rgb.shape[1], rgb.shape[0]) != W:
                raise VqaError("E_VC_FRAME_SIZE", {"i": k, "shape": list(rgb.shape[:2])})
            frames.append(fr)
            entries.append({"i": k, "t_us": fr.t_us, "render_index": ri, "file": os.path.relpath(p, mp.parent),
                            "sha256": fr.sha256, "file_sha256": fsha})
        meta = {"schema": vframe.SCHEMA, "width": W[0], "height": W[1], "channels": 3, "pixel_format": "rgb24",
                "fps_num": fps, "fps_den": 1, "count": len(frames), "storage": "png_dir", "raw_path": None,
                "frame_bytes": W[0] * W[1] * 3, "frames": entries, "hints": "region_hints.jsonl",
                "still_probe": None, "scope": self.scope(run_dir),
                "provenance": {"adapter_id": ADAPTER_ID, "adapter_version": ADAPTER_VERSION,
                               "capture_receipt_sha256": _sha_file(mp)}}
        vframe.validate_manifest(meta)
        return vframe.MemoryFrameSource(frames, meta)

    def hints(self, run_dir):
        mp, root, cap, recs = self._read(run_dir)
        tp = (cap.get("telemetry") or {}).get("path", "capture/telemetry.jsonl")
        try:
            tpath = _resolve(root, mp, tp)
        except VqaError:
            tpath = mp.parent / "telemetry.jsonl"
            if not tpath.is_file():
                return None
        by_ri = {}
        with open(tpath, encoding="utf-8") as fh:
            for n, line in enumerate(fh, 1):
                if line.strip():
                    try:
                        row = json.loads(line)
                    except ValueError:
                        raise VqaError("E_VC_FRAME_SCHEMA", {"path": str(tpath), "line": n})
                    if isinstance(row, dict) and isinstance(row.get("render_index"), int):
                        by_ri[row["render_index"]] = row
        W = H = None
        rows = []
        vp = cap.get("viewport_px")
        if isinstance(vp, list) and len(vp) == 2:
            W, H = vp
        for k, r in enumerate(recs):
            tel = by_ri.get(r.get("render_index"))
            if tel is None:
                continue
            w, h = (W, H) if W else tuple(tel.get("viewport_px", (0, 0)))
            if w and h:
                rows += _rows_for(tel, k, w, h)
        return iter(rows)

    def still_probe(self, run_dir):
        d = Path(run_dir)
        for sub in ("still_probe", "probe"):
            pngs = sorted((d / sub).glob("*.png")) if (d / sub).is_dir() else []
            if pngs:
                break
        else:
            return None
        frames = []
        for k, p in enumerate(pngs):
            frames.append(vframe.Frame(k, k * 33333, None, read_png(p)))
        h, w = frames[0].rgb.shape[:2]
        meta = {"schema": vframe.SCHEMA, "width": w, "height": h, "channels": 3, "pixel_format": "rgb24",
                "storage": "png_dir", "count": len(frames)}
        return vframe.MemoryFrameSource(frames, meta)

    def scope(self, run_dir):
        mp, root, cap, recs = self._read(run_dir)
        bs = cap.get("build_seq")
        return {"app": _slug(cap.get("adapter_id", "godot"), 32), "scene": _slug(cap.get("ruleset_id", "unknown"), 48),
                "res": "%dx%d" % tuple(cap.get("viewport_px") or (0, 0)),
                "build_seq": bs if isinstance(bs, int) and not isinstance(bs, bool) and bs >= 0 else None}


def convert(in_dir, out_dir):
    """Write out_dir/frames.manifest.json (+ region_hints.jsonl when telemetry has rects). All-or-nothing: on error
    nothing is written."""
    a = GodotAdapter()
    src = a.frames(in_dir)
    hints = a.hints(in_dir)
    rows = list(hints) if hints is not None else None
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    meta = dict(src.meta)
    # frame files are referenced relative to the out dir
    mp, _root = _roots(in_dir)
    for e in meta["frames"]:
        e["file"] = os.path.relpath((mp.parent / e["file"]).resolve(), out.resolve())
    if rows is None:
        meta["hints"] = None
    else:
        canon.write_atomic(out / "region_hints.jsonl", "".join(canon.dumps(r) for r in rows).encode("utf-8"))
    vframe.write_manifest(out / "frames.manifest.json", meta)
    return {"code": "OK", "rc": 0, "detail": {"frames": len(src), "hints": None if rows is None else len(rows),
                                              "manifest_sha256": _sha_file(out / "frames.manifest.json")}}


def main(argv=None):
    ap = argparse.ArgumentParser(prog="python3 -m vadapt.godot.from_capture_dir")
    ap.add_argument("--in", dest="inp", required=True)
    ap.add_argument("--out", required=True)
    try:
        ns = ap.parse_args(argv)
    except SystemExit:
        sys.stdout.write(result_line(result_obj("E_USAGE")))
        return 2
    try:
        res = convert(ns.inp, ns.out)
    except VqaError as e:
        sys.stdout.write(result_line(e.to_obj()))
        return e.rc
    sys.stdout.write(result_line(res))
    return 0


if __name__ == "__main__":
    sys.exit(main())
