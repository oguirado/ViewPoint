# @module {"id":"vc.parallel","layer":4,"stage":"L4","owner":"ARCH","deps":["vc.errors","vc.s1","vc.topology"],"inputs":"frames,grid,workers,cpus","outputs":"TILE_DTYPE[count,N]","invariants":["integer-only","deterministic","byte-identical-to-serial"],"anti_uses":["per-engine branches","clock"],"oracle":"tests/test_parallel.py","book":"HB-VC-a0-arch"}
"""@module vc.parallel L4 - frame-parallel S1: describe_many() (CDESIGN_CENG F3). One full describe per frame in forked
workers pinned to the big cores; results land in one preallocated shared tile array (no pickling). Output equals the
serial full describe byte for byte; workers=1 runs in-process."""
import multiprocessing as mp
import os
from multiprocessing import shared_memory

import numpy as np

from . import desc
from .errors import VqaError

try:  # CP1 module: absence only disables automatic pinning
    from . import topology
except ImportError:  # pragma: no cover
    topology = None

_JOIN_S = 600
_G = {}  # fork-inherited read-only inputs of the running pool


def frames_array(source):
    """Frames of a source as uint8[count,H,W,3]: the raw memmap when the source carries one, else a stacked copy."""
    raw = getattr(source, "raw_array", None)
    if raw is not None:
        return raw
    return np.stack([np.asarray(f.rgb) for f in source])


def default_cpus():
    """Big-core ids from topology (CPU part 0xd85), [] when unknown (then workers are not pinned)."""
    if topology is None:
        return []
    try:
        return list(topology.big_cpus())
    except Exception:  # unreadable /proc: run unpinned
        return []


def _one(frames, grid, params, k, lazy_xh=False):
    tiles, _ = desc.describe_padded(grid.pad(frames[k]), grid, None, None, params, lazy_xh=lazy_xh)
    return tiles


def _worker(widx, ks, shm_name, shape, cpu):
    try:
        if cpu is not None and hasattr(os, "sched_setaffinity"):
            os.sched_setaffinity(0, {cpu})
        shm = shared_memory.SharedMemory(name=shm_name)
        out = np.ndarray(shape, dtype=desc.TILE_DTYPE, buffer=shm.buf)
        frames, grid, params = _G["frames"], _G["grid"], _G["params"]
        for k in ks:
            out[k] = _one(frames, grid, params, k, _G["lazy_xh"])
        del out
        shm.close()
    except BaseException:
        os._exit(3)
    os._exit(0)


def describe_many(source, grid, workers=1, cpus=None, params=None, lazy_xh=False):  # @anchor:vc.parallel.describe_many
    """source (FrameSource or uint8[count,H,W,3]) -> TILE_DTYPE[count,N], row k = full describe of frame k.
    workers<=1: serial in-process. cpus: explicit cpu ids (worker w pins to cpus[w % len]); None: big cores from
    topology, empty: unpinned. Results are assembled by frame index, never by arrival.
    lazy_xh=True leaves hashes zero for the caller to fill after sequential S2 classification."""
    frames = source if isinstance(source, np.ndarray) else frames_array(source)
    count = len(frames)
    if frames.shape[1:] != (grid.H, grid.W, 3):
        raise VqaError("E_VC_FRAME_SHAPE", {"shape": list(frames.shape[1:]), "grid": grid.ident})
    workers = max(1, min(int(workers), count)) if count else 1
    if workers == 1:
        out = np.zeros((count, grid.N), dtype=desc.TILE_DTYPE)
        for k in range(count):
            out[k] = _one(frames, grid, params, k, lazy_xh)
        return out
    cpus = default_cpus() if cpus is None else list(cpus)
    shape = (count, grid.N)
    shm = shared_memory.SharedMemory(create=True, size=max(1, count * grid.N * desc.TILE_DTYPE.itemsize))
    procs = []
    try:
        _G.update(frames=frames, grid=grid, params=params, lazy_xh=lazy_xh)
        ctx = mp.get_context("fork")
        for w in range(workers):
            ks = list(range(w, count, workers))
            cpu = cpus[w % len(cpus)] if cpus else None
            p = ctx.Process(target=_worker, args=(w, ks, shm.name, shape, cpu))
            p.start()
            procs.append(p)
        bad = []
        for w, p in enumerate(procs):
            p.join(_JOIN_S)
            if p.is_alive():
                p.kill()
                p.join()
            if p.exitcode != 0:
                bad.append(w)
        if bad:
            raise VqaError("E_IO", {"reason": "describe worker failed", "workers": bad[:8]})
        view = np.ndarray(shape, dtype=desc.TILE_DTYPE, buffer=shm.buf)
        out = view.copy()
        del view
        return out
    finally:
        for p in procs:
            if p.is_alive():
                p.kill()
                p.join()
        _G.clear()
        shm.close()
        shm.unlink()
